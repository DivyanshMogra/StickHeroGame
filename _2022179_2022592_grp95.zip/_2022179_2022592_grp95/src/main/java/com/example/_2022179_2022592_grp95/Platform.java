package com.example._2022179_2022592_grp95;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.Random;

public class Platform {

    private Rectangle platform;

    public Platform(double x, double y, double width, double height) {
        platform = new Rectangle(x, y, width, height);
        platform.setFill(Color.BLACK);
    }

    public Rectangle getPlatform() {
        return platform;
    }

    public void setX(double x) {
        platform.setX(x);
    }

    public void setY(double y) {
        platform.setY(y);
    }

    public void setWidth(double width) {
        platform.setWidth(width);
    }

    public void setHeight(double height) {
        platform.setHeight(height);
    }
    public double getPlatformWidth() {
        return platform.getWidth();
    }

    public double getPlatformX() {
        return platform.getX();
    }

    public double getPlatformY() {
        return platform.getY()  ;
    }
}
