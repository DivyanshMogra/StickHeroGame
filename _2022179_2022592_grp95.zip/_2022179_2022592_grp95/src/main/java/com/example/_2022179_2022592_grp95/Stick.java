package com.example._2022179_2022592_grp95;

import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.concurrent.atomic.AtomicBoolean;

public class Stick extends Pane {
    private double stickLength;
    private Line line;
    private AtomicBoolean extending = new AtomicBoolean(false);


    public Stick(double x, double y, double stickLength) {
        this.stickLength = stickLength;

        // Set the initial position of the stick on top of platform1
        double stickStartX = x ; // Adjust as needed based on the platform size
        double stickStartY = y;

        this.line = new Line(stickStartX, stickStartY, stickStartX, stickStartY - stickLength);
        getChildren().add(line);

        setOnKeyPressed(this::handleKeyPress);
        setOnKeyReleased(this::handleKeyRelease);

        setFocusTraversable(true);
    }
    public double getStartX() {
        return line.getStartX();
    }

    public double getStartY() {
        return line.getStartY();
    }

    private void handleKeyPress(KeyEvent event) {
        if (event.getCode() == KeyCode.SPACE) {
            extending.set(true);
        }
    }

    private void handleKeyRelease(KeyEvent event) {
        if (event.getCode() == KeyCode.SPACE) {
            extending.set(false);
        }
    }

    public void extend(double extension) {
        if (extending.get()) {
            double newY = line.getEndY() - extension;
            if (newY >= 0.0) {
                line.setEndY(newY);
                stickLength += extension;
            }
        }
    }

    public void release() {
        Rotate rotate = new Rotate(90, line.getStartX(), line.getStartY());
        line.getTransforms().add(rotate);
        extending.set(false);
    }

    public double getStickLength() {
        return stickLength;
    }

    public void reset() {

        this.stickLength = 0;
        this.line.setEndY(this.line.getStartY());
        this.line.getTransforms().clear();
    }

}

