module com.example._2022179_2022592_grp95 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example._2022179_2022592_grp95 to javafx.fxml;
    exports com.example._2022179_2022592_grp95;
}