package com.example._2022179_2022592_grp95;

import javafx.animation.AnimationTimer;
import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

import javafx.scene.input.KeyCode;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class HelloApplication extends Application {

    private Scene scene1, scene2, scene3;
    private Stick stickOnSecondScreen;
    private Group root2;
    private ImageView guy;
    private double initialGuyX = 160;
    private double initialGuyY = 410;

    @Override
    public void start(Stage stage) throws Exception {
        scene1 = createScene1(stage);
        scene2 = createScene2(stage);
        scene3 = createScene3(stage);

        stage.setScene(scene1);
        stage.setTitle("Stick Hero");
        stage.setResizable(false);
        stage.show();
    }

    private Scene createScene1(Stage stage) {
        Group root1 = new Group();
        Scene scene = new Scene(root1, 750, 750, Color.CRIMSON);
        Text text = new Text();
        Polygon triangle = new Polygon();
        Polygon triangle2 = new Polygon();
        Polygon triangle3 = new Polygon();
        Polygon triangle4 = new Polygon();
        Circle circle = new Circle();
        Rectangle rectangle = new Rectangle();
        Button button = new Button();
        Image icon = new Image("C:\\Users\\Harsh\\IdeaProjects\\_2022179_2022592_grp95\\src\\sh.png");
        stage.getIcons().add(icon);

        // Text (Stick hero)
        text.setText("Stick \nHero");
        text.setX(312);
        text.setY(50);
        text.setFont(Font.font("Lucida Calligraphy", 50));
        text.setFill(Color.BLACK);

        // Triangles (BG)
        triangle.getPoints().setAll(
                120.0, 400.0,
                5.0, 745.0,
                220.0, 745.0
        );
        triangle.setFill(Color.LIGHTBLUE);
        triangle.setOpacity(0.15);

        triangle2.getPoints().setAll(
                330.0, 400.0,
                225.0, 745.0,
                430.0, 745.0
        );
        triangle2.setFill(Color.LIGHTBLUE);
        triangle2.setOpacity(0.15);

        triangle3.getPoints().setAll(
                540.0, 400.0,
                435.0, 745.0,
                640.0, 745.0
        );
        triangle3.setFill(Color.LIGHTBLUE);
        triangle3.setOpacity(0.15);

        triangle4.getPoints().setAll(
                750.0, 400.0,
                645.0, 745.0,
                850.0, 745.0
        );
        triangle4.setFill(Color.LIGHTBLUE);
        triangle4.setOpacity(0.15);

        // Circle (BG)
        circle.setCenterX(80);
        circle.setCenterY(250);
        circle.setRadius(100);
        circle.setOpacity(0.15);
        circle.setFill(Color.LIGHTBLUE);

        // Rectangle (Block)
        rectangle.setFill(Color.BLACK);
        rectangle.setX(350);
        rectangle.setY(450);
        rectangle.setWidth(100);
        rectangle.setHeight(300);

        // Button
        button.setText("Play");
        button.setMinSize(60, 60);
        button.setLayoutX(350);
        button.setLayoutY(300);
        button.setFont(Font.font("Lucida Calligraphy", 25));
        button.setStyle("-fx-background-color: #000000; " +
                "-fx-text-fill: white; " +
                ";"
        );

        button.setOnAction(e -> stage.setScene(scene2));

        root1.getChildren().addAll(text, triangle, triangle2, triangle3, triangle4, circle, rectangle, button);
        return scene;
    }

    private Scene createScene2(Stage stage) {
        Random random = new Random();
        if (root2 == null) {
            root2 = new Group();
        }
        root2.getChildren().clear();
        Scene scene = new Scene(root2, 750, 750, Color.CRIMSON);
        stickOnSecondScreen = new Stick(200, 450, 0);

        Polygon triangle = new Polygon();
        Polygon triangle2 = new Polygon();
        Polygon triangle3 = new Polygon();
        Polygon triangle4 = new Polygon();
        Circle circle = new Circle();

        triangle.getPoints().setAll(
                120.0, 400.0,
                5.0, 745.0,
                220.0, 745.0
        );

        triangle.setFill(Color.LIGHTBLUE);
        triangle.setOpacity(0.15);

        triangle2.getPoints().setAll(
                330.0, 400.0,
                225.0, 745.0,
                430.0, 745.0
        );
        triangle2.setFill(Color.LIGHTBLUE);
        triangle2.setOpacity(0.15);

        triangle3.getPoints().setAll(
                540.0, 400.0,
                435.0, 745.0,
                640.0, 745.0
        );
        triangle3.setFill(Color.LIGHTBLUE);
        triangle3.setOpacity(0.15);

        triangle4.getPoints().setAll(
                750.0, 400.0,
                645.0, 745.0,
                850.0, 745.0

        );
        triangle4.setFill(Color.LIGHTBLUE);
        triangle4.setOpacity(0.15);

        // Circle (BG)
        circle.setCenterX(80);
        circle.setCenterY(250);
        circle.setRadius(100);
        circle.setOpacity(0.15);
        circle.setFill(Color.LIGHTBLUE);

        Platform platform1 = new Platform(100, 450, 100, 300);
        guy = new ImageView(new Image("C:\\Users\\Harsh\\IdeaProjects\\_2022179_2022592_grp95\\src\\Guy.jpg"));
        guy.setX(160);
        guy.setY(410);
        guy.setFitHeight(40);
        guy.setFitWidth(40);


        double distance = random.nextDouble() * 300;
        if (distance > 400) {
            distance = distance / 2;
        }

        double width = random.nextDouble() * 100;
        if (width < 50) {
            width = width + 30;
        } else if (width > 120) {
            width = 120;
        }
        Platform platform2 = new Platform(300 + distance, 450, width, 300);

        root2.getChildren().addAll(triangle, triangle2, triangle3, triangle4, circle,
                platform1.getPlatform(), platform2.getPlatform(), stickOnSecondScreen, guy);

        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.SPACE) {
                stickOnSecondScreen.extend(10.0);
            }
        });

        scene.setOnKeyReleased(e -> {
            if (e.getCode() == KeyCode.SPACE) {
                stickOnSecondScreen.release();
                moveGuyAlongStick(guy , stickOnSecondScreen , stage);




                double distanceBetweenPlatforms = platform2.getPlatformX() - (platform1.getPlatformX() + platform1.getPlatformWidth());
                if (stickOnSecondScreen.getStickLength() > distanceBetweenPlatforms + platform2.getPlatformWidth() || stickOnSecondScreen.getStickLength() < distanceBetweenPlatforms) {
                    PauseTransition pause = new PauseTransition(Duration.seconds(3));
                    pause.setOnFinished(event -> stage.setScene(scene3));
                    pause.play();
                }

            }
        });

        return scene;
    }

    private Scene createScene3(Stage stage){
        Group root3 = new Group();
        Scene scene = new Scene(root3, 750, 750, Color.CRIMSON);

        Polygon triangle = new Polygon();
        Polygon triangle2 = new Polygon();
        Polygon triangle3 = new Polygon();
        Polygon triangle4 = new Polygon();
        Circle circle = new Circle();
        Text text3 = new Text();
        Button button = new Button();

        text3.setText("GAME OVER");
        text3.setX(312);
        text3.setY(50);
        text3.setFont(Font.font("Lucida Calligraphy", 25));
        text3.setFill(Color.BLACK);

        triangle.getPoints().setAll(
                120.0, 400.0,
                5.0, 745.0,
                220.0, 745.0
        );
        triangle.setFill(Color.LIGHTBLUE);
        triangle.setOpacity(0.15);

        triangle2.getPoints().setAll(
                330.0, 400.0,
                225.0, 745.0,
                430.0, 745.0
        );
        triangle2.setFill(Color.LIGHTBLUE);
        triangle2.setOpacity(0.15);

        triangle3.getPoints().setAll(
                540.0, 400.0,
                435.0, 745.0,
                640.0, 745.0
        );
        triangle3.setFill(Color.LIGHTBLUE);
        triangle3.setOpacity(0.15);

        triangle4.getPoints().setAll(
                750.0, 400.0,
                645.0, 745.0,
                850.0, 745.0

        );
        triangle4.setFill(Color.LIGHTBLUE);
        triangle4.setOpacity(0.15);

        // Circle (BG)
        circle.setCenterX(80);
        circle.setCenterY(250);
        circle.setRadius(100);
        circle.setOpacity(0.15);
        circle.setFill(Color.LIGHTBLUE);
        button.setText("Replay");
        button.setMinSize(60, 60);
        button.setLayoutX(350);
        button.setLayoutY(300);
        button.setFont(Font.font("Lucida Calligraphy", 25));
        button.setStyle("-fx-background-color: #000000; " +
                "-fx-text-fill: white; " +
                ";"
        );
        button.setOnAction(e -> {
            stickOnSecondScreen.reset();
            root2.getChildren().remove(stickOnSecondScreen);
            root2.getChildren().add(stickOnSecondScreen);


            guy.setX(initialGuyX);
            guy.setY(initialGuyY);
            stickOnSecondScreen.setTranslateX(0);
            stickOnSecondScreen.setTranslateY(0);

            stage.setScene(scene2);
        });

        root3.getChildren().addAll(triangle, triangle2, triangle3, triangle4, circle,text3, button);

        return scene;
    }

    private void moveGuyAlongStick(ImageView guy, Stick stick, Stage stage) {

        double initialX = 160;
        double initialY = 410;

        // Reset the position of the guy
        guy.setX(initialX);
        guy.setY(initialY);

        guy.setTranslateX(0);
        guy.setTranslateY(0);

        TranslateTransition moveGuy = new TranslateTransition(Duration.seconds(2), guy);
        moveGuy.setToX(stick.getStickLength() + 10);
        moveGuy.setOnFinished(event -> {

            guy.setX(initialGuyX);
            guy.setY(initialGuyY);
        });

        moveGuy.play();
    }



    public static void main(String[] args) {
        launch();
    }
}